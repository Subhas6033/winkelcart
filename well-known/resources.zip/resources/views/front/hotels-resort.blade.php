@extends('front.layouts.app')
@section('content')
  <style>
    /* Mobile Footer Styling */
    @media (max-width: 768px) {
      .footer-nav .container {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding: 10px 15px;
        background-color: #1c1c1c;
      }

      .footer-nav-list {
        border-bottom: 1px solid #333;
        padding: 10px 0;
      }

      .nav-title {
        font-size: 16px;
        font-weight: 700;
        color: #fff;
        display: flex;
        justify-content: space-between;
        cursor: pointer;
      }

      .footer-links {
        display: none;
        margin-top: 8px;
      }

      .footer-links a {
        display: block;
        font-size: 14px;
        color: #bbb;
        text-decoration: none;
        margin-bottom: 6px;
      }

      .footer-links a:hover {
        color: #ff9500;
      }

      /* Active (Expanded) */
      .footer-nav-list.active .footer-links {
        display: block;
      }

      /* Footer Bottom */
      .footer-bottom {
        background-color: #141414;
        text-align: center;
        padding: 15px;
        border-top: 1px solid #333;
      }

      .footer-bottom .payment-img {
        max-width: 200px;
        margin-bottom: 10px;
      }

      .footer-bottom .copyright {
        font-size: 13px;
        color: #bbb;
      }

      .footer-bottom .copyright a {
        color: #ff9500;
        text-decoration: none;
      }
    }

    /* MOBILE NAV BTNS CSS*/

    .mobile-menu {
      display: none;
      /* Initially hidden */
      flex-direction: column;
      background: #222;
      padding: 1rem;
    }

    .mobile-menu.show {
      display: flex;
      /* Shown when "show" class is added */
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
    }

    a {
      text-decoration: none;
    }

    /* ========= TOP BANNER ========= */
    .top-banner {
      background: white;
      color: red;
      text-align: right;
      padding: 0.5rem 2rem;
      font-weight: bold;
      font-size: 0.9rem;
    }

    /* ========= HEADER ========= */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #222;
      color: white;
      padding: 1rem;
      position: relative;
      z-index: 100;
    }

    .header img {
      height: 80px;
    }

    .logo-text {
      font-size: 1.5rem;
      color: #d72b2b;
      margin-top: 0.3rem;
    }

    .search-container {
      display: flex;
      justify-content: center;
      margin-top: 1rem;
    }

    .search-box {
      width: 60%;
      display: flex;
      background: white;
      border: 1px solid #ccc;
      border-radius: 25px;
      overflow: hidden;
    }

    .search-box input {
      flex: 1;
      padding: 0.7rem;
      border: none;
      outline: none;
      font-size: 1rem;
    }

    .search-box button {
      background: white;
      border: none;
      padding: 0 1rem;
      cursor: pointer;
    }

    .menu-category {
      vertical-align: middle;
      font-size: 20px;
    }

    /* ========= NAVIGATION BAR (DESKTOP) ========= */
    nav.desktop-nav {
      background: #222;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      padding: 0.5rem 1rem;
      gap: 1.5rem;
    }

    nav.desktop-nav a {
      color: white;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 0.4rem;
      font-size: 0.95rem;
      transition: color 0.2s ease;
    }

    nav.desktop-nav a:hover {
      color: #4caf50;
    }


    .menu-toggle {
      display: none;
      font-size: 2rem;
      position: absolute;
      top: 0;
      left: 10;
      transform: ;
      cursor: pointer;
      z-index: 9999;
    }


    .mobile-menu {
      display: none;
      flex-direction: column;
      background: transparent;
      color: white;
      padding: 20px;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 9999;
    }

    .mobile-menu.show {
      display: flex;
    }



    .mobile-menu nav {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .mobile-menu nav a {
      color: white;
      display: inline-block;
      align-items: center;
      gap: 0.4rem;
      font-size: 1rem;
      padding: 4px 0;
    }


    .main {
      text-align: center;
      padding: 2rem;
    }

    .main h1 {
      font-size: 2.2rem;
      color: #1e3dd3;
    }

    .main h2 {
      font-size: 2.5rem;
      color: #ff6600;
      margin-top: 0.5rem;
    }

    @media (max-width: 768px) {
      nav.desktop-nav {
        display: none;
      }

      .search-container {
        display: none;
      }

      .menu-toggle {
        display: block;
      }
    }

    @media (min-width: 769px) {
      .mobile-menu {
        display: none;
      }
    }

    /*new banner*/

    * {
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 40px;
      background-color: #f9f9f9;
    }

    .stay-section {
      position: relative;
      max-width: 1330px;
      margin: 30px auto;
      overflow: hidden;
    }

    h2 {
      margin-bottom: 20px;
      font-size: 24px;
      color: #333;
    }

    .stay-slider {
      display: flex;
      overflow-x: auto;
      scroll-behavior: smooth;
      gap: 15px;
      padding-bottom: 10px;
      max-width: 1330px;
      margin: 30px auto;
    }

    .stay-card {
      min-width: 180px;
      height: 240px;
      border-radius: 12px;
      overflow: hidden;
      flex-shrink: 0;
      position: relative;
      cursor: pointer;
      transition: transform 0.3s;
    }

    .stay-card:hover {
      transform: scale(1.05);
    }

    .stay-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .stay-label {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: rgba(0, 0, 0, 0.4);
      color: white;
      padding: 10px;
      text-align: center;
      font-weight: bold;
    }

    .slider-button {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      background-color: white;
      border: none;
      border-radius: 50%;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
      width: 35px;
      height: 35px;
      cursor: pointer;
      z-index: 10;
    }

    .left-button {
      left: -15px;
    }

    .right-button {
      right: -15px;
    }

    @media (max-width: 600px) {
      .stay-card {
        min-width: 140px;
        height: 180px;
      }
    }

    /* banner top*/
    .main-banner {
      display: flex;
      justify-content: center;
      margin-top: 40px;
      padding: 20px;
      background-color: transparent;
    }

    .inner-banner {
      display: flex;
      gap: 25px;
      flex-wrap: wrap;
      justify-content: center;
    }

    .banner-card {
      display: flex;
      align-items: center;
      background-color: #f6f6f6;
      border-radius: 15px;
      height: 105px;
      width: 390px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
      overflow: hidden;
    }

    .banner-img {
      width: fit-content;
      height: fit-content;
    }

    .banner-img img {

      width: 140px;
      height: 100px;
      object-fit: cover;
      border-radius: 15px;
      margin-right: 10px;
      margin-left: 02px;
      display: block;


    }

    .banner-card .text {
      font-family: Arial, sans-serif;
    }

    .banner-card h4 {
      font-size: 15px;
      margin: 0 0 8px;
      color: #000;
    }

    .banner-card a {
      font-size: 13px;
      text-decoration: none;
      color: #006ce4;
      font-weight: bold;
    }
  </style>
  </head>

  <body>

    <!-- banner top-->
    <div class="main-banner">
      <div class="inner-banner">
        @foreach($hotels_banner->products as $product)
        <div class="banner-card">
          <div class="banner-img">
            <img src="{{ asset('uploads/products/' . $product->image) }}" alt="{{ $product->name }}">
          </div>
          <div class="text">
            <h4>{{ $product->desc }}</h4>
            <a href="#">Book now →</a>
          </div>
        </div>
        @endforeach
      </div>
    </div>

    <!-- new banner-->
    <div class="stay-section">
      <h2>Discover your new favourite stay</h2>

      <button class="slider-button left-button" onclick="scrollSlider(-1)">❮</button>
      <button class="slider-button right-button" onclick="scrollSlider(1)">❯</button>

      <div class="stay-slider" id="staySlider">
        @foreach($hotels_resort->products as $product)
        <a class="stay-card" href="#">
          <img src="{{ asset('uploads/products/' . $product->image) }}" alt="{{ $product->name }}">
          <div class="stay-label">{{ $product->name }}</div>
        </a>
        @endforeach
      </div>
    </div>

    <script>
      function scrollSlider(direction) {
        const slider = document.getElementById("staySlider");
        const scrollAmount = slider.offsetWidth / 2;
        slider.scrollBy({
          left: direction * scrollAmount,
          behavior: "smooth"
        });
      }
    </script>
@endsection