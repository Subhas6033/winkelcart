<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Cart</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
        background: hsl(57 79.3% 60.5%);
        font-family: 'Poppins', sans-serif;
    }
    .cart-container {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1);
        padding: 2rem;
        margin: 3rem auto;
        max-width: 1100px;
    }
    .table img {
        width: 70px;
        border-radius: 10px;
    }
    .navbar-brand img {
        height: 70px;
    }
  </style>
</head>
<body>

  <div class="container cart-container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <a class="navbar-brand" href="{{ url('/') }}">
            <img src="{{ asset('assets/images/logo/Winkel_Shop__2_-removebg-preview.png') }}" 
                alt="Winkel Logo" 
                style="height: 60px;">
        </a>
        <h2 class="mb-0">🛒 Your Shopping Cart</h2>
    </div>
    <!-- <a class="navbar-brand" href="{{ url('/') }}">
        <img src="{{ asset('assets/images/logo/Winkel_Shop__2_-removebg-preview.png') }}" alt="Winkel Logo">
    </a>
    <h2 class="mb-4">🛒 Your Shopping Cart</h2> -->
    @if (session('success'))
      <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if ($cartItems->isEmpty())
      <p>Your cart is empty.</p>
    @else
      <table class="table align-middle">
        <thead>
          <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Price (₹)</th>
            <th>Quantity</th>
            <th>Subtotal (₹)</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          @foreach ($cartItems as $item)
          <tr>            
            <td><img src="{{ asset('uploads/products/'.$item->products->image) }}"></td>
            <td>{{ $item->products->name }}</td>
            <td>{{ number_format($item->price, 2) }}</td>
            <td>
              <form action="{{ url('cart_update', $item->id) }}" method="POST" class="d-flex">
                @csrf
                <input type="number" name="quantity" min="1" value="{{ $item->quantity }}" class="form-control w-50 me-2">
                <button class="btn btn-sm btn-outline-success">Update</button>
              </form>
            </td>
            <td>{{ number_format($item->price * $item->quantity, 2) }}</td>
            <td>
              <form action="{{ url('cart_remove', $item->id) }}" method="get">
                @csrf
                @method('DELETE')
                <button class="btn btn-sm btn-outline-danger">Remove</button>
              </form>
            </td>
          </tr>          
          @endforeach
        </tbody>
      </table>

      <div class="d-flex justify-content-between align-items-center mt-4">
        <h4>Total: ₹{{ number_format($total, 2) }}</h4>
        <!-- <a href="{{ route('checkout.buy-now', ['id' => 0]) }}" class="btn btn-warning fw-bold px-4">Buy Now</a> -->
      </div>

      <!-- resources/views/front/cart.blade.php -->
      <div class="text-center mt-5">
          <h4>Scan QR to Pay</h4>
          <img src="{{ asset('assets/images/qr/upi_qr.png') }}" alt="QR Code" width="200">

          <form action="{{ route('place_order') }}" method="POST" enctype="multipart/form-data" class="mt-4">
            @csrf
            <input type="hidden" name="total_amount" value="{{ number_format($total, 2) }}">
            <div class="mb-3">
                <label for="payment_screenshot" class="form-label">Upload Payment Screenshot</label>
                <input type="file" class="form-control @error('payment_screenshot') is-invalid @enderror" 
                      name="payment_screenshot" accept="image/*" required>

                @error('payment_screenshot')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <button type="submit" class="btn btn-success">Place Order</button>
          </form>

      </div>

    @endif
  </div>

</body>
</html>
