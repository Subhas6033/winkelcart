<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $product->name ?? 'Product Details' }}</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: hsl(57 79.3% 60.5%);
            font-family: 'Poppins', sans-serif;
        }

        .product-detail {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin: 3rem auto;
            max-width: 1100px;
        }

        .product-image img {
            /* width: 100%; */
            border-radius: 15px;
        }

        .product-info h2 {
            font-weight: 700;
            color: #333;
        }

        .product-price {
            font-size: 1.8rem;
            color: #d9534f;
            font-weight: 600;
        }

        .product-description {
            margin-top: 1rem;
            color: #555;
            line-height: 1.6;
        }

        .btn-buy {
            background-color: #ff6f00;
            color: #fff;
            font-weight: 600;
            border: none;
        }

        .btn-buy:hover {
            background-color: #e65c00;
        }

        .btn-cart {
            background-color: #007bff;
            color: #fff;
            font-weight: 600;
            border: none;
        }

        .btn-cart:hover {
            background-color: #0056b3;
        }

        .navbar {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .navbar-brand img {
            height: 50px;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                <img src="{{ asset('assets/images/logo/Winkel_Shop__2_-removebg-preview.png') }}" alt="Winkel Logo">
            </a>
            <div class="d-flex align-items-center gap-3">
                @auth
                    <span class="fw-semibold text-dark">Hi, {{ Auth::user()->name }}</span>
                    <!-- <a href="{{ route('logout') }}" class="btn btn-outline-danger btn-sm">Logout</a> -->
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger btn-sm">Logout</button>
                    </form>
                @else
                    <a href="{{ url('login') }}" class="btn btn-outline-primary btn-sm">Login</a>
                @endauth
            </div>
        </div>
    </nav>

    <!-- Product Detail Section -->
    <div class="container product-detail">
        <div class="row g-4 align-items-center">

            <!-- Left Side: Product Image -->
            <div class="col-md-6 product-image text-center">
                <img src="{{ $product->image_url ?? asset('uploads/products/'.$product->image) }}" alt="{{ $product->name }}">
                <!-- <img src="{{ $product->image_url ?? asset('assets/images/products/sample-product.jpg') }}" alt="Product Image"> -->
            </div>

            <!-- Right Side: Product Info -->
            <div class="col-md-6 product-info">
                <h2>{{ $product->name ?? 'Sample Product Name' }}</h2>
                <p class="product-price">₹{{ $product->offer_price ?? $product->total_price }}</p>

                <p class="product-description">
                    {{ $product->description ?? 'This is a high-quality product designed to meet your needs and exceed expectations. Perfect for everyday use and made from premium materials.' }}
                </p>

                <!-- <div class="d-flex align-items-center my-3">
                    <label for="quantity" class="me-2 fw-bold">Quantity:</label>
                    <input type="number" id="quantity" class="form-control w-25" value="1" min="1">
                </div> -->

                <div class="d-flex gap-3 mt-4">
                    <form action="{{ url('cart_add', $product->id ?? 1) }}" method="GET">
                        @csrf
                        <button type="submit" class="btn btn-cart px-4 py-2">
                            <i class="bi bi-cart"></i> Add to Cart
                        </button>
                    </form>

                    <!-- <form action="{{ route('checkout.buy-now', $product->id ?? 1) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-buy px-4 py-2">
                            <i class="bi bi-bag"></i> Buy Now
                        </button>
                    </form> -->
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
