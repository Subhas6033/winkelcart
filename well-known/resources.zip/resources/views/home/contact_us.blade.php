@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Winkel | Contact us</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
    <!-- Navbar -->

    <!-- /.navbar -->

    <!-- Main Sidebar Container -->


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Contact us</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Contact us</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="card">
          <div class="card-body row align-items-center">
            <div class="col-5 text-center d-flex align-items-center justify-content-center">
              <a href=""><img src="{{ asset('assets_admin/images/yashujee_logo.png') }}" width="180px" alt=""></a>
            </div>
            <div class="col-7">
              <p class="lead text-center"><b>Winkel India Automation</b> <br>
                42, Metcalfe Street Kolkata 700013
                Near Bank of India Mission Row Branch
                Printer Support</p>
            </div>

          </div>
        </div>

        <div class="card">
          <div class="card-body px-0 pb-0 table-responsive">
            <table class="table">
              <thead class="thead-light">
                <tr>
                  <th>Sl. No.</th>
                  <th>Name</th>
                  <th>Number</th>
                  <th>Email ID</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Karan Kumar Pandey</td>
                  <td>+9147321883</td>
                  <td>printer.support@utkarsh.bank</td>
                  <td>Printer Support</td>
                </tr>
                <tr class="bg-light">
                  <td>2</td>
                  <td>Kush Singh</td>
                  <td>+9147321884</td>
                  <td></td>
                  <td>Printer Support</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Neeraj Updhay</td>
                  <td>+9147321885</td>
                  <td></td>
                  <td>Printer Support</td>
                </tr>
                <tr class="bg-light">
                  <td>4</td>
                  <td>Anand Sharma</td>
                  <td>+9147321881</td>
                  <td> servicing.icon@gmail.com</td>
                  <td>Consumable (Toner, Drum, Ink & Maintenance Box)</td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>Surajit Sanpui </td>
                  <td>+9147321882</td>
                  <td> winkel.ecomerce@gmail.com</td>
                  <td>Service Support (Printer & Printer Spare Parts)</td>
                </tr>
                <tr class="bg-light">
                  <td>6</td>
                  <td>Manu Prasad</td>
                  <td>+9883727249</td>
                  <td></td>
                  <td>Manager</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="card">
          <div class="card-body ">
            <p class="mb-0">Plz visit below given link : <a href="https://youtu.be/SF9D7rX1C4g">Our Company Profile Video Link</a></p>
            
          </div>
        </div>

        <!-- Default box -->


      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


    <!-- Control Sidebar -->

    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../../plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../../dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->

</body>

</html>
@endsection