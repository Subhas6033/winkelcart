<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Winkel: Login</title>
  <!-- Favicon -->
  <link rel="icon" href="{{ asset('assets_admin/img/brand/favicon.png') }}" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="{{ asset('assets_admin/vendor/nucleo/css/nucleo.css') }}" type="text/css">
  <link rel="stylesheet" href="{{ asset('assets_admin/vendor/@fortawesome/fontawesome-free/css/all.min.css') }}" type="text/css">
  <!-- Argon CSS -->
  <link rel="stylesheet" href="{{ asset('assets_admin/css/argon.css?v=1.2.0') }}" type="text/css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="{{ asset('assets_admin/plugins/overlayScrollbars/css/all.min.css') }}">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="{{ asset('assets_admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{ asset('assets_admin/dist/css/adminlte.min.css') }}">
</head>

<body class="bg-white">
  <!-- Main content -->
  <div class="main-content">
    <!-- Header -->
    <div class="header header-bg py-7 py-lg-8 pt-lg-9">      
    </div>
    <!-- Page content -->
    <div class="container mt--8 mt--10 pb-5">
      <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
          <div class="card border-0 mb-0" style="background: linear-gradient(169deg, #ffd700, #050713c9);">
          <!-- <div class="card border-0 mb-0" style="background: linear-gradient(169deg, #2b3895, #050713c9);"> -->
            <div class="card-header bg-transparent px-2">
              <div class="logo text-center">
                <a href="{{url('/')}}"><img width="150px" src="{{ asset('assets/images/logo/Winkel_Shop__2_-removebg-preview.png') }}" alt=""></a>                
              </div>
            </div>
            <div class="card-body px-lg-5 py-lg-5">
              
              <!-- <div class="text-center text-muted mb-4">
                <small>Or sign in with credentials</small>
              </div> -->
              @if (count($errors) > 0)
              <div class="alert alert-danger">
                <ul>
                  @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
                  @endforeach
                </ul>
              </div>
              @endif
              @if(Session::has('error_login'))
              <div>
                <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error_login') }}</p>
              </div>
              @endif
              <form role="form" method="POST" action="{{ route('login')}}">
                @csrf
                <div class="form-group mb-3">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                    </div>
                    <input class="form-control form-control-user" type="text" name="email" value="{{ old('email') }}" autocomplete="email" placeholder="Email" autofocus>
                    @error('email')
                    <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    </div>
                    <input class="form-control form-control-user" type="password" name="password" autocomplete="current-password" placeholder="Password">
                    @error('password')
                    <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                  </div>
                </div>


                @if (Route::has('password.request'))
                <!-- <div class="col-6 pd-0">
                      <a href="#" class="text-grey"><small>Forgot password?</small></a>
                    </div> -->

                @endif


                <!-- <div class="custom-control custom-control-alternative custom-checkbox">
                  <input class="custom-control-input" id=" customCheckLogin" type="checkbox">
                  <label class="custom-control-label" for=" customCheckLogin">
                    <span class="text-muted">Remember me</span>
                  </label>
                </div> -->
                <div class="text-center">
                  <button type="submit" class="btn btn-success my-4">Login</button>
                  <a type="button" class="btn my-4 btn-danger" href="{{ url('login') }}">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Core -->
  <script src="{{ asset('assets_admin/vendor/jquery/dist/jquery.min.js') }}"></script>
  <script src="{{ asset('assets_admin/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('assets_admin/vendor/js-cookie/js.cookie.js') }}"></script>
  <script src="{{ asset('assets_admin/vendor/jquery.scrollbar/jquery.scrollbar.min.js') }}"></script>
  <script src="{{ asset('assets_admin/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js') }}"></script>
  <script src="{{ asset('assets_admin/js/argon.js?v=1.2.0') }}"></script>
</body>

</html>