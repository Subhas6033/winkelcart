@extends('layouts.app')

@section('content')
<div class="content-wrapper">
  <div class="container-fluid">

    <div class="row">
      <div class="col-xl-12 mt-3 order-xl-1">
        <div class="card">
          <div class="card-header">
            <div class="row align-items-center">
              <div class="col-12">
                <h3 class="mb-0">Add Role</h3>
              </div>
            </div>
          </div>
          @if ($errors->any())
          <div class="alert alert-danger">
            <ul>
              @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
          @endif
          <div class="card-body">
            <form action="{{ route('roles.store') }}" method="POST">
              @csrf
              <div class="pl-lg-4">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="form-group">
                      <label class="form-control-label" for="input-username">Name</label>
                      <input type="text" name="name" class="form-control" required>
                    </div>
                  </div>

                  <div class="col-lg-12">
                    <div class="form-group">
                      <label class="form-control-label" for="input-username">Permission</label>
                      <table class="table table-bordered">
                        @foreach($permission as $row)
                        <tr>
                          <td width="60%">{{ $row->menu_title }}</td>
                          <td>
                            @foreach($row->url as $row_url)
                            <div class="form-check">

                              <input class="form-check-input" name="permission[]" type="checkbox" value="{{$row_url->id}}">
                              <label class="form-check-label" for="check1">{{$row_url->name}}</label>
                            </div>
                            @endforeach
                          </td>
                          <td>
                            <div class="form-check">
                              <input class="form-check-input check-all" id="check-all" type="checkbox" value="1">
                              <label class="form-check-label" for="check1">Check All</label>
                            </div>
                          </td>
                        </tr>
                        @endforeach
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div class="text-center">
                <button type="submit" class="btn btn-primary my-4">Save</button>
                <a href="{{ route('roles.index') }}" class="btn btn-outline-danger my-4">Cancel</a>
              </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->



@endsection


@section('script_scetion')
<script>
  $('.check-all').change(function() {
    if ($(this).prop('checked') == true) {
      var chkbox = $(this).parent().parent().prev('td');
      chkbox.find('input[type=checkbox]').each(function() {
        this.checked = true;
      });
    } else {
      var chkbox = $(this).parent().parent().prev('td');
      chkbox.find('input[type=checkbox]').each(function() {
        this.checked = false;
      });
    }

  });
</script>
@endsection